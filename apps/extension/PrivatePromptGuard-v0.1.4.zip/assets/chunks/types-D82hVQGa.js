const n=["email","phone","dni","iban","card","jwt","api_key","pem","secret_assignment","nano_sensitive"],s={enabled:!0,sensitivity:"balanced",language:"auto",nanoAssist:!0,enabledTypes:[...n]},a="ppg_prefs_v1";function i(e){return typeof e=="string"&&n.includes(e)}export{n as A,s as D,a as S,i};
//# sourceMappingURL=types-D82hVQGa.js.map
